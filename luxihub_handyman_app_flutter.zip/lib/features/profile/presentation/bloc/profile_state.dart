import 'package:equatable/equatable.dart';
import 'package:luxihub_handyman/features/profile/domain/entities/profile.dart';

abstract class ProfileState extends Equatable {
  const ProfileState();

  @override
  List<Object?> get props => [];
}

class ProfileInitial extends ProfileState {
  const ProfileInitial();
}

class ProfileLoading extends ProfileState {
  const ProfileLoading();
}

class ProfileLoaded extends ProfileState {
  final Profile profile;
  const ProfileLoaded(this.profile);

  @override
  List<Object> get props => [profile];
}

class ProfileUpdating extends ProfileState {
  final Profile profile;
  const ProfileUpdating(this.profile);

  @override
  List<Object> get props => [profile];
}

class ProfileUploadingAvatar extends ProfileState {
  final Profile profile;
  const ProfileUploadingAvatar(this.profile);

  @override
  List<Object> get props => [profile];
}

class ProfileError extends ProfileState {
  final String message;
  const ProfileError(this.message);

  @override
  List<Object> get props => [message];
}
