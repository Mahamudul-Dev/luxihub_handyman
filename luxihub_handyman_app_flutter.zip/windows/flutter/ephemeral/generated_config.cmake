# Generated code do not commit.
file(TO_CMAKE_PATH "E:\\Sdk\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "E:\\Projects\\flutter-projects\\luxihub\\luxihub_handyman" PROJECT_DIR)

set(FLUTTER_VERSION "0.1.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=E:\\Sdk\\flutter"
  "PROJECT_DIR=E:\\Projects\\flutter-projects\\luxihub\\luxihub_handyman"
  "FLUTTER_ROOT=E:\\Sdk\\flutter"
  "FLUTTER_EPHEMERAL_DIR=E:\\Projects\\flutter-projects\\luxihub\\luxihub_handyman\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=E:\\Projects\\flutter-projects\\luxihub\\luxihub_handyman"
  "FLUTTER_TARGET=E:\\Projects\\flutter-projects\\luxihub\\luxihub_handyman\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDEuNQ==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049MmM5ZWIyMDczOQ==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049MDUyZjMxZDExNQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMS4z"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=E:\\Projects\\flutter-projects\\luxihub\\luxihub_handyman\\.dart_tool\\package_config.json"
)
